#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "tables.h"

static char	*mock_dict_get(t_dict *d, const char *key)
{
	(void)d;
	if (strcmp(key, "0") == 0) return "zero";
	if (strcmp(key, "13") == 0) return "thirteen";
	if (strcmp(key, "20") == 0) return "twenty";
	if (strcmp(key, "100") == 0) return "hundred";
	if (strcmp(key, "1000") == 0) return "thousand";
	if (strcmp(key, "1000000") == 0) return "million";
	if (strcmp(key, "1000000000") == 0) return "billion";
	return NULL;
}

char	*dict_get(t_dict *d, const char *key)
{
	return mock_dict_get(d, key);
}

void	dict_free(t_dict **d)
{
	(void)d;
}

int	main(void)
{
	const char		**small;
	const char		**tens;
	const char		*hundred;
	const char		**scales;
	t_build_error	result;
	t_dict			*mock_dict = NULL;

	result = build_tables_arrays(mock_dict, 3, &small, &tens, &hundred, &scales);
	
	assert(result == BUILD_SUCCESS);
	assert(small[0] != NULL && strcmp(small[0], "zero") == 0);
	assert(small[13] != NULL && strcmp(small[13], "thirteen") == 0);
	assert(tens[2] != NULL && strcmp(tens[2], "twenty") == 0);
	assert(tens[0] == NULL && tens[1] == NULL);
	assert(hundred != NULL && strcmp(hundred, "hundred") == 0);
	assert(scales[0] == NULL);
	assert(scales[1] != NULL && strcmp(scales[1], "thousand") == 0);
	assert(scales[2] != NULL && strcmp(scales[2], "million") == 0);
	assert(scales[3] != NULL && strcmp(scales[3], "billion") == 0);

	free_tables_arrays(small, tens, scales);
	printf("All tests passed!\n");
	return 0;
}