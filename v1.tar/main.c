/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zchakir <zchakir@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 10:00:00 by zchakir           #+#    #+#             */
/*   Updated: 2024/01/01 10:00:00 by zchakir          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

/*
** Affiche le message d'erreur standard
*/
void	print_error(void)
{
	ft_putstr("Error\n");
}

/*
** Affiche le message d'erreur du dictionnaire
*/
void	print_dict_error(void)
{
	ft_putstr("Dict Error\n");
}

/*
** Fonction principale du programme
** Gère les arguments et lance la conversion
*/
int	main(int argc, char **argv)
{
	t_dict	*dict;
	char	*number;
	char	*normalized_number;
	char	*result;
	char	*dict_file;

	if (argc < 2 || argc > 3)
	{
		print_error();
		return (1);
	}
	dict_file = (argc == 3) ? argv[1] : "numbers.dict";
	number = (argc == 3) ? argv[2] : argv[1];
	if (!is_valid_number(number))
	{
		print_error();
		return (1);
	}
	dict = dict_load(dict_file);
	if (!dict)
	{
		print_dict_error();
		return (1);
	}
	normalized_number = normalize_number(number);
	result = convert_number(normalized_number, dict);
	free(normalized_number);
	if (!result)
	{
		print_dict_error();
		dict_free(&dict);
		return (1);
	}
	ft_putstr(result);
	ft_putstr("\n");
	free(result);
	dict_free(&dict);
	return (0);
}