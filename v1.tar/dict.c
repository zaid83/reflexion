/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dict.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zchakir <zchakir@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 10:00:00 by zchakir           #+#    #+#             */
/*   Updated: 2024/01/01 10:00:00 by zchakir          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "dict.h"
#include "rush-02.h"

/* Structure pour une entrée du dictionnaire */
typedef struct s_dict_entry
{
	char					*key;
	char					*value;
	struct s_dict_entry		*next;
}	t_dict_entry;

/* Structure du dictionnaire */
struct s_dict
{
	t_dict_entry	*entries;
	int				size;
};

/*
** Lit le contenu complet d'un fichier
*/
static char	*read_file(const char *filename)
{
	int		fd;
	char	*buffer;
	char	*content;
	int		bytes_read;
	int		total_size;

	fd = open(filename, O_RDONLY);
	if (fd == -1)
		return (NULL);
	content = malloc(1);
	if (!content)
		return (NULL);
	content[0] = '\0';
	total_size = 0;
	buffer = malloc(BUFFER_SIZE + 1);
	if (!buffer)
	{
		free(content);
		return (NULL);
	}
	while ((bytes_read = read(fd, buffer, BUFFER_SIZE)) > 0)
	{
		buffer[bytes_read] = '\0';
		content = realloc(content, total_size + bytes_read + 1);
		if (!content)
		{
			free(buffer);
			close(fd);
			return (NULL);
		}
		ft_strcat(content + total_size, buffer);
		total_size += bytes_read;
	}
	free(buffer);
	close(fd);
	return (content);
}

/*
** Supprime les espaces en début et fin de chaîne
*/
static char	*trim_whitespace(char *str)
{
	char	*end;
	char	*start;
	int		i;

	while (*str == ' ' || *str == '\t' || *str == '\n' || *str == '\r')
		str++;
	if (*str == '\0')
		return (ft_strdup(""));
	end = str + ft_strlen(str) - 1;
	while (end > str && (*end == ' ' || *end == '\t' || *end == '\n' || *end == '\r'))
		end--;
	*(end + 1) = '\0';
	start = malloc(ft_strlen(str) + 1);
	if (!start)
		return (NULL);
	i = 0;
	while (str[i])
	{
		start[i] = str[i];
		i++;
	}
	start[i] = '\0';
	return (start);
}

/*
** Parse une ligne du dictionnaire et crée une entrée
*/
static t_dict_entry	*parse_line(char *line)
{
	t_dict_entry	*entry;
	char			*colon;
	char			*key;
	char			*value;
	char			*trimmed_line;

	trimmed_line = trim_whitespace(line);
	if (!trimmed_line || *trimmed_line == '\0')
	{
		free(trimmed_line);
		return (NULL);
	}
	colon = trimmed_line;
	while (*colon && *colon != ':')
		colon++;
	if (*colon != ':')
	{
		free(trimmed_line);
		return (NULL);
	}
	*colon = '\0';
	key = trim_whitespace(trimmed_line);
	value = trim_whitespace(colon + 1);
	if (!key || !value || *key == '\0' || *value == '\0')
	{
		free(key);
		free(value);
		free(trimmed_line);
		return (NULL);
	}
	entry = malloc(sizeof(t_dict_entry));
	if (!entry)
	{
		free(key);
		free(value);
		free(trimmed_line);
		return (NULL);
	}
	entry->key = key;
	entry->value = value;
	entry->next = NULL;
	free(trimmed_line);
	return (entry);
}

/*
** Charge un dictionnaire depuis un fichier
*/
t_dict	*dict_load(const char *filename)
{
	t_dict			*dict;
	char			*content;
	char			*line;
	char			*next_line;
	t_dict_entry	*entry;
	t_dict_entry	*last;

	content = read_file(filename);
	if (!content)
		return (NULL);
	dict = malloc(sizeof(t_dict));
	if (!dict)
	{
		free(content);
		return (NULL);
	}
	dict->entries = NULL;
	dict->size = 0;
	last = NULL;
	line = content;
	while (*line)
	{
		next_line = line;
		while (*next_line && *next_line != '\n')
			next_line++;
		if (*next_line == '\n')
		{
			*next_line = '\0';
			next_line++;
		}
		entry = parse_line(line);
		if (entry)
		{
			if (!dict->entries)
				dict->entries = entry;
			else
				last->next = entry;
			last = entry;
			dict->size++;
		}
		line = next_line;
	}
	free(content);
	return (dict);
}

/*
** Récupère la valeur associée à une clé
*/
char	*dict_get(t_dict *dict, const char *key)
{
	t_dict_entry	*current;

	if (!dict || !key)
		return (NULL);
	current = dict->entries;
	while (current)
	{
		if (ft_strcmp(current->key, (char *)key) == 0)
			return (current->value);
		current = current->next;
	}
	return (NULL);
}

/*
** Libère la mémoire du dictionnaire
*/
void	dict_free(t_dict **dict)
{
	t_dict_entry	*current;
	t_dict_entry	*next;

	if (!dict || !*dict)
		return ;
	current = (*dict)->entries;
	while (current)
	{
		next = current->next;
		free(current->key);
		free(current->value);
		free(current);
		current = next;
	}
	free(*dict);
	*dict = NULL;
}