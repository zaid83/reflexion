/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dict.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zchakir <zchakir@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 10:00:00 by zchakir           #+#    #+#             */
/*   Updated: 2024/01/01 10:00:00 by zchakir          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DICT_H
# define DICT_H

# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>

/* Structure opaque pour le dictionnaire */
typedef struct s_dict	t_dict;

/* Charge un dictionnaire depuis un fichier */
t_dict	*dict_load(const char *filename);

/* Récupère la valeur associée à une clé */
char	*dict_get(t_dict *d, const char *key);

/* Libère la mémoire du dictionnaire */
void	dict_free(t_dict **d);

#endif