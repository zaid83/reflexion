/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   result.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zchakir <zchakir@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 10:00:00 by zchakir           #+#    #+#             */
/*   Updated: 2024/01/01 10:00:00 by zchakir          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

/*
** Initialise une structure de résultat
*/
t_result	*result_init(void)
{
	t_result	*result;

	result = malloc(sizeof(t_result));
	if (!result)
		return (NULL);
	result->capacity = BUFFER_SIZE;
	result->str = malloc(result->capacity);
	if (!result->str)
	{
		free(result);
		return (NULL);
	}
	result->str[0] = '\0';
	result->len = 0;
	return (result);
}

/*
** Ajoute une chaîne au résultat
*/
int	result_append(t_result *result, const char *str)
{
	int		str_len;
	int		new_len;
	char	*new_str;

	if (!result || !str)
		return (0);
	str_len = ft_strlen((char *)str);
	new_len = result->len + str_len;
	if (new_len >= result->capacity)
	{
		while (result->capacity <= new_len)
			result->capacity *= 2;
		new_str = malloc(result->capacity);
		if (!new_str)
			return (0);
		ft_strcat(new_str, result->str);
		free(result->str);
		result->str = new_str;
	}
	ft_strcat(result->str + result->len, (char *)str);
	result->len = new_len;
	return (1);
}

/*
** Finalise le résultat et retourne la chaîne
*/
char	*result_finalize(t_result *result)
{
	char	*final_str;

	if (!result)
		return (NULL);
	final_str = ft_strdup(result->str);
	result_free(result);
	return (final_str);
}

/*
** Libère la mémoire du résultat
*/
void	result_free(t_result *result)
{
	if (!result)
		return ;
	if (result->str)
		free(result->str);
	free(result);
}