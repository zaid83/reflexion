/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zchakir <zchakir@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 10:00:00 by zchakir           #+#    #+#             */
/*   Updated: 2024/01/01 10:00:00 by zchakir          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

/*
** Calcule le nombre maximum d'échelles nécessaires
*/
static int	calculate_k_max(char *number)
{
	int	len;

	len = ft_strlen(number);
	return ((len - 1) / 3);
}

/*
** Convertit un groupe de 3 chiffres en mots
*/
char	*convert_group(char *group, t_dict *dict, const char **small,
		const char **tens, const char *hundred)
{
	(void)dict;
	t_result	*result;
	int			len;
	int			hundreds_digit;
	int			tens_digit;
	int			units_digit;
	int			two_digit_num;

	result = result_init();
	if (!result)
		return (NULL);
	len = ft_strlen(group);
	hundreds_digit = (len >= 3) ? group[len - 3] - '0' : 0;
	tens_digit = (len >= 2) ? group[len - 2] - '0' : 0;
	units_digit = group[len - 1] - '0';
	two_digit_num = tens_digit * 10 + units_digit;
	if (hundreds_digit > 0)
	{
		if (!result_append(result, small[hundreds_digit]))
			return (NULL);
		if (!result_append(result, " "))
			return (NULL);
		if (!result_append(result, hundred))
			return (NULL);
		if (two_digit_num > 0)
		{
			if (!result_append(result, " "))
				return (NULL);
		}
	}
	if (two_digit_num < 20 && two_digit_num > 0)
	{
		if (!result_append(result, small[two_digit_num]))
			return (NULL);
	}
	else if (two_digit_num >= 20)
	{
		if (!result_append(result, tens[tens_digit]))
			return (NULL);
		if (units_digit > 0)
		{
			if (!result_append(result, " "))
				return (NULL);
			if (!result_append(result, small[units_digit]))
				return (NULL);
		}
	}
	return (result_finalize(result));
}

/*
** Divise un nombre en groupes de 3 chiffres et les convertit
*/
char	*convert_number(char *number, t_dict *dict)
{
	const char	**small;
	const char	**tens;
	const char	*hundred;
	const char	**scales;
	t_result	*result;
	int			k_max;
	int			len;
	int			start;
	int			group_len;
	char		group[4];
	char		*group_text;
	int			scale;
	int			i;

	if (!number || ft_strcmp(number, "0") == 0)
		return (ft_strdup(dict_get(dict, "0")));
	k_max = calculate_k_max(number);
	if (build_tables_arrays(dict, k_max, &small, &tens, &hundred, &scales)
		!= BUILD_SUCCESS)
		return (NULL);
	result = result_init();
	if (!result)
	{
		free_tables_arrays(small, tens, scales);
		return (NULL);
	}
	len = ft_strlen(number);
	start = 0;
	scale = k_max;
	while (start < len)
	{
		group_len = len - start;
		if (group_len > 3)
			group_len = (len - start - 1) % 3 + 1;
		i = 0;
		while (i < group_len)
		{
			group[i] = number[start + i];
			i++;
		}
		group[group_len] = '\0';
		if (ft_strcmp(group, "000") != 0 && ft_strcmp(group, "00") != 0
			&& ft_strcmp(group, "0") != 0)
		{
			if (result->len > 0 && !result_append(result, " "))
			{
				free_tables_arrays(small, tens, scales);
				result_free(result);
				return (NULL);
			}
			group_text = convert_group(group, dict, small, tens, hundred);
			if (!group_text || !result_append(result, group_text))
			{
				free(group_text);
				free_tables_arrays(small, tens, scales);
				result_free(result);
				return (NULL);
			}
			free(group_text);
			if (scale > 0 && (!result_append(result, " ")
				|| !result_append(result, scales[scale])))
			{
				free_tables_arrays(small, tens, scales);
				result_free(result);
				return (NULL);
			}
		}
		start += group_len;
		scale--;
	}
	free_tables_arrays(small, tens, scales);
	return (result_finalize(result));
}