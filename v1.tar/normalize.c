#include <stdlib.h>
#include <unistd.h>
 int is_digit(char c)
{
	return (c >= '0' && c <= '9');
}
char	*normalize_input_value(char *input)
{
	int		i;
	int		start;
	char	*res;
	int		len;

	if (!input || !*input)
		return (NULL);
	i = 0;
	while (input[i])
	{
		if (!is_digit(input[i]))
			return (NULL);
		i++;
	}
	start = 0;
	while (input[start] == '0' && input[start + 1] != '\0')
		start++;
	len = 0;
	while (input[start + len])
		len++;
	res = (char *)malloc(sizeof(char) * (len + 1));
	if (!res)
		return (NULL);
	i = 0;
	while (i < len)
	{
		res[i] = input[start + i];
		i++;
	}
	res[i] = '\0';
	return (res);
}


int	main(int argc, char **argv)
{
	char	*norm;

	if (argc != 2)
	{
		write(1, "Error\n", 6);
		return (1);
	}
	norm = normalize_input_value(argv[1]);
	if (!norm)
	{
		write(1, "Error\n", 6);
		return (1);
	}
	write(1, norm, 0); 
	free(norm);
	return (0);
}




