/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tables.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zchakir <zchakir@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 10:00:00 by zchakir           #+#    #+#             */
/*   Updated: 2024/01/01 10:00:00 by zchakir          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TABLES_H
# define TABLES_H

# include "dict.h"

/* Énumération des erreurs de construction des tables */
typedef enum e_build_error
{
	BUILD_SUCCESS = 1,
	BUILD_MALLOC_ERROR = 0,
	BUILD_DICT_ERROR = -1
}	t_build_error;

/* Génère une clé pour les puissances de 1000 (1000^i) */
char			*pow1000_key(int i);

/* Construit les tables de conversion depuis le dictionnaire */
t_build_error	build_tables_arrays(t_dict *dict, int k_max,
					const char ***small_out, const char ***tens_out,
					const char **hundred_out, const char ***scales_out);

/* Libère la mémoire des tables */
void			free_tables_arrays(const char **small, const char **tens,
					const char **scales);

#endif