/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tables.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zchakir <zchakir@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 10:00:00 by zchakir           #+#    #+#             */
/*   Updated: 2024/01/01 10:00:00 by zchakir          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "tables.h"

/*
** Génère une clé pour les puissances de 1000
** Exemple: pow1000_key(1) retourne "1000", pow1000_key(2) retourne "1000000"
*/
char	*pow1000_key(int i)
{
	char	*key;
	int		len;
	int		j;

	len = 1 + 3 * i;
	key = malloc(len + 1);
	if (!key)
		return (NULL);
	key[0] = '1';
	j = 1;
	while (j <= 3 * i)
	{
		key[j] = '0';
		j++;
	}
	key[len] = '\0';
	return (key);
}

/* Structure pour organiser les trois tables */
typedef struct s_tables
{
	const char	**small;
	const char	**tens;
	const char	**scales;
}	t_tables;

/*
** Alloue la mémoire pour les trois tables
** small_size: taille du tableau des petits nombres (0-19)
** tens_size: taille du tableau des dizaines (20, 30, 40, ...)
** scales_size: taille du tableau des échelles (thousand, million, ...)
*/
static t_tables	*alloc_tables(size_t small_size, size_t tens_size,
	size_t scales_size)
{
	t_tables	*result;

	result = malloc(sizeof(t_tables));
	if (!result)
		return (NULL);
	result->small = malloc(small_size * sizeof(char *));
	result->tens = malloc(tens_size * sizeof(char *));
	result->scales = malloc(scales_size * sizeof(char *));
	if (!result->small || !result->tens || !result->scales)
	{
		free(result->small);
		free(result->tens);
		free(result->scales);
		free(result);
		return (NULL);
	}
	return (result);
}

/*
** Remplit le tableau des petits nombres (0 à 19)
*/
static t_build_error	fill_small(t_dict *dict, const char **small)
{
	char	key[3];
	int		i;

	i = 0;
	while (i < 20)
	{
		if (i < 10)
		{
			key[0] = '0' + i;
			key[1] = '\0';
		}
		else
		{
			key[0] = '1';
			key[1] = '0' + (i - 10);
			key[2] = '\0';
		}
		small[i] = dict_get(dict, key);
		if (!small[i])
			return (BUILD_DICT_ERROR);
		i++;
	}
	return (BUILD_SUCCESS);
}

/*
** Remplit le tableau des dizaines (20, 30, 40, ..., 90)
*/
static t_build_error	fill_tens(t_dict *dict, const char **tens)
{
	char	key[3];
	int		i;

	tens[0] = NULL;
	tens[1] = NULL;
	i = 2;
	while (i < 10)
	{
		key[0] = '0' + i;
		key[1] = '0';
		key[2] = '\0';
		tens[i] = dict_get(dict, key);
		if (!tens[i])
			return (BUILD_DICT_ERROR);
		i++;
	}
	return (BUILD_SUCCESS);
}

/*
** Remplit le tableau des échelles (thousand, million, billion, ...)
*/
static t_build_error	fill_scales(t_dict *dict, const char **scales,
	int k_max)
{
	char	*key;
	int		i;

	scales[0] = NULL;
	i = 1;
	while (i <= k_max)
	{
		key = pow1000_key(i);
		if (!key)
			return (BUILD_MALLOC_ERROR);
		scales[i] = dict_get(dict, key);
		free(key);
		if (!scales[i])
			return (BUILD_DICT_ERROR);
		i++;
	}
	return (BUILD_SUCCESS);
}

/*
** Construit toutes les tables nécessaires pour la conversion
** dict: dictionnaire contenant les correspondances nombre -> mot
** k_max: nombre maximum d'échelles à gérer
** Les paramètres _out sont remplis avec les tables créées
*/
t_build_error	build_tables_arrays(t_dict *dict, int k_max,
	const char ***small_out, const char ***tens_out,
	const char **hundred_out, const char ***scales_out)
{
	t_tables		*tables;
	t_build_error	err;

	tables = alloc_tables(20, 10, k_max + 1);
	if (!tables)
		return (BUILD_MALLOC_ERROR);
	err = fill_small(dict, tables->small);
	if (err != BUILD_SUCCESS)
	{
		free_tables_arrays(tables->small, tables->tens, tables->scales);
		free(tables);
		return (err);
	}
	err = fill_tens(dict, tables->tens);
	if (err != BUILD_SUCCESS)
	{
		free_tables_arrays(tables->small, tables->tens, tables->scales);
		free(tables);
		return (err);
	}
	*hundred_out = dict_get(dict, "100");
	if (!*hundred_out)
	{
		free_tables_arrays(tables->small, tables->tens, tables->scales);
		free(tables);
		return (BUILD_DICT_ERROR);
	}
	err = fill_scales(dict, tables->scales, k_max);
	if (err != BUILD_SUCCESS)
	{
		free_tables_arrays(tables->small, tables->tens, tables->scales);
		free(tables);
		return (err);
	}
	*small_out = tables->small;
	*tens_out = tables->tens;
	*scales_out = tables->scales;
	free(tables);
	return (BUILD_SUCCESS);
}

/*
** Libère la mémoire allouée pour les tables
*/
void	free_tables_arrays(const char **small, const char **tens,
	const char **scales)
{
	free(small);
	free(tens);
	free(scales);
}