/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validation.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zchakir <zchakir@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 10:00:00 by zchakir           #+#    #+#             */
/*   Updated: 2024/01/01 10:00:00 by zchakir          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

/*
** Vérifie si un caractère est un chiffre
*/
static int	is_digit(char c)
{
	return (c >= '0' && c <= '9');
}

/*
** Vérifie si une chaîne représente un nombre valide
** Un nombre valide ne contient que des chiffres et n'est pas vide
*/
int	is_valid_number(char *str)
{
	int	i;

	if (!str || *str == '\0')
		return (0);
	i = 0;
	while (str[i])
	{
		if (!is_digit(str[i]))
			return (0);
		i++;
	}
	if (i > MAX_NUMBER_LEN)
		return (0);
	return (1);
}

/*
** Normalise un nombre en supprimant les zéros en tête
** Retourne "0" si le nombre ne contient que des zéros
*/
char	*normalize_number(char *str)
{
	char	*normalized;
	int		i;
	int		j;

	if (!str)
		return (NULL);
	i = 0;
	while (str[i] == '0')
		i++;
	if (str[i] == '\0')
		return (ft_strdup("0"));
	normalized = malloc(ft_strlen(str + i) + 1);
	if (!normalized)
		return (NULL);
	j = 0;
	while (str[i])
	{
		normalized[j] = str[i];
		i++;
		j++;
	}
	normalized[j] = '\0';
	return (normalized);
}