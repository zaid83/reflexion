/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_simple.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zchakir <zchakir@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 10:00:00 by zchakir           #+#    #+#             */
/*   Updated: 2024/01/01 10:00:00 by zchakir          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"
#include <stdio.h>

int	main(void)
{
	printf("Test de compilation réussi!\n");
	printf("Longueur de 'test': %d\n", ft_strlen("test"));
	printf("Validation de '123': %d\n", is_valid_number("123"));
	printf("Validation de 'abc': %d\n", is_valid_number("abc"));
	return (0);
}