/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush-02.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zchakir <zchakir@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 10:00:00 by zchakir           #+#    #+#             */
/*   Updated: 2024/01/01 10:00:00 by zchakir          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RUSH_02_H
# define RUSH_02_H

# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include "dict.h"
# include "tables.h"

/* Constantes pour la taille des buffers */
# define BUFFER_SIZE 1024
# define MAX_NUMBER_LEN 39

/* Structure pour stocker le résultat de conversion */
typedef struct s_result
{
	char	*str;
	int		len;
	int		capacity;
}	t_result;

/* Fonctions principales */
int		ft_strlen(char *str);
char	*ft_strdup(char *src);
char	*ft_strcat(char *dest, char *src);
int		ft_strcmp(char *s1, char *s2);
void	ft_putstr(char *str);

/* Fonctions de validation et normalisation */
int		is_valid_number(char *str);
char	*normalize_number(char *str);

/* Fonctions de conversion */
char	*convert_number(char *number, t_dict *dict);
char	*convert_group(char *group, t_dict *dict, const char **small,
			const char **tens, const char *hundred);

/* Fonctions utilitaires pour le résultat */
t_result	*result_init(void);
int			result_append(t_result *result, const char *str);
char		*result_finalize(t_result *result);
void		result_free(t_result *result);

#endif